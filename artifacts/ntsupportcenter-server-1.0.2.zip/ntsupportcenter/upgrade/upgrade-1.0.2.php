<?php
if (!defined('_PS_VERSION_')) { exit; }
function upgrade_module_1_0_2($module)
{
    $cols=Db::getInstance()->executeS(
        'SHOW COLUMNS FROM `'._DB_PREFIX_.'ntsupport_ticket` LIKE "notify_mail_sent"'
    );
    if(!$cols){
        if(!Db::getInstance()->execute(
            'ALTER TABLE `'._DB_PREFIX_.'ntsupport_ticket`
             ADD `notify_mail_sent` TINYINT(1) NOT NULL DEFAULT 0 AFTER `source`'
        )) return false;
    }
    return true;
}
