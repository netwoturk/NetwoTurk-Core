<?php
class NtsupportcenterApiModuleFrontController extends ModuleFrontController
{
    public $ssl=true;

    public function initContent()
    {
        header('Content-Type: application/json; charset=utf-8');
        try{
            if(($_SERVER['REQUEST_METHOD']??'')!=='POST') $this->out(405,['ok'=>false,'error'=>'method_not_allowed']);
            $key=(string)($_SERVER['HTTP_X_NT_API_KEY']??Tools::getValue('api_key',''));
            $expected=(string)Configuration::get('NTSC_API_KEY');
            if(!$expected || !hash_equals($expected,$key)) $this->out(401,['ok'=>false,'error'=>'unauthorized']);
            $action=(string)Tools::getValue('action','create');
            if($action==='create') $this->createTicket();
            if($action==='reply') $this->customerReply();
            if($action==='status') $this->ticketStatus();
            if($action==='detail') $this->ticketDetail();
            $this->out(400,['ok'=>false,'error'=>'invalid_action']);
        }catch(Throwable $e){
            PrestaShopLogger::addLog('ntsupportcenter API: '.$e->getMessage(),3);
            $this->out(500,['ok'=>false,'error'=>'server_error']);
        }
    }

    private function createTicket()
    {
        foreach(['company','domain','contact_name','subject','message'] as $f)
            if(trim((string)Tools::getValue($f,''))==='') $this->out(422,['ok'=>false,'error'=>'missing_'.$f]);

        $now=date('Y-m-d H:i:s');
        $priority=(string)Tools::getValue('priority','normal');
        if(!in_array($priority,['low','normal','high','urgent'],true)) $priority='normal';
        $domain=strtolower(trim((string)Tools::getValue('domain')));
        $domain=preg_replace('#^https?://#','',$domain);
        $domain=preg_replace('#^www\.#','',$domain);
        $domain=explode('/',$domain)[0];

        $row=[
            'ticket_no'=>'PENDING-'.Tools::passwdGen(12),
            'company'=>pSQL(Tools::getValue('company')),
            'product_name'=>pSQL(Tools::getValue('product_name','')),
            'domain'=>pSQL($domain),
            'license_id'=>pSQL(Tools::getValue('license_id','')),
            'contact_name'=>pSQL(Tools::getValue('contact_name')),
            'contact_phone'=>pSQL(Tools::getValue('contact_phone','')),
            'contact_email'=>pSQL(Tools::getValue('contact_email','')),
            'category'=>pSQL(Tools::getValue('category','Genel')),
            'priority'=>pSQL($priority),
            'subject'=>pSQL(Tools::getValue('subject')),
            'status'=>'open','source'=>pSQL(Tools::getValue('source','api')),
            'created_at'=>$now,'updated_at'=>$now
        ];
        if(!Db::getInstance()->insert('ntsupport_ticket',$row)) $this->out(500,['ok'=>false,'error'=>'insert_failed']);
        $id=(int)Db::getInstance()->Insert_ID();
        $no=$this->module->makeTicketNo($id);
        Db::getInstance()->update('ntsupport_ticket',['ticket_no'=>pSQL($no)],'id_ticket='.$id);

        $message=(string)Tools::getValue('message');
        Db::getInstance()->insert('ntsupport_message',['id_ticket'=>$id,'sender_type'=>'customer','sender_name'=>$row['contact_name'],'message'=>pSQL($message,true),'created_at'=>$now]);
        $row['ticket_no']=$no;
        $row['id_ticket']=$id;
        $this->saveOptionalAttachment($id);
        $this->module->sendNewTicketMail($row,$message);
        $this->out(201,['ok'=>true,'ticket_no'=>$no,'id_ticket'=>$id]);
    }


    private function saveOptionalAttachment($idTicket)
    {
        $b64=trim((string)Tools::getValue('attachment_base64',''));
        $original=trim((string)Tools::getValue('attachment_name',''));
        $mime=trim((string)Tools::getValue('attachment_mime',''));
        if($b64==='' || $original==='') return;

        $allowed=['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp'];
        if(!isset($allowed[$mime])) $this->out(422,['ok'=>false,'error'=>'attachment_type']);
        $raw=base64_decode($b64,true);
        if($raw===false || strlen($raw)>5*1024*1024) $this->out(422,['ok'=>false,'error'=>'attachment_size']);

        $dir=_PS_MODULE_DIR_.'ntsupportcenter/private_uploads/';
        if(!is_dir($dir) && !@mkdir($dir,0750,true)) $this->out(500,['ok'=>false,'error'=>'attachment_storage']);
        if(!file_exists($dir.'.htaccess')) @file_put_contents($dir.'.htaccess',"Require all denied\\nDeny from all\\n");
        $stored=sha1(uniqid('',true).$idTicket).'.'.$allowed[$mime];
        if(@file_put_contents($dir.$stored,$raw)===false) $this->out(500,['ok'=>false,'error'=>'attachment_storage']);

        Db::getInstance()->insert('ntsupport_attachment',[
            'id_ticket'=>(int)$idTicket,'id_message'=>0,'stored_name'=>pSQL($stored),
            'original_name'=>pSQL(basename($original)),'mime_type'=>pSQL($mime),
            'file_size'=>(int)strlen($raw),'created_at'=>date('Y-m-d H:i:s')
        ]);
    }

    private function customerReply()
    {
        $no=trim((string)Tools::getValue('ticket_no')); $msg=trim((string)Tools::getValue('message'));
        $t=Db::getInstance()->getRow('SELECT * FROM `'._DB_PREFIX_.'ntsupport_ticket` WHERE ticket_no="'.pSQL($no).'"');
        if(!$t || $msg==='') $this->out(404,['ok'=>false,'error'=>'ticket_not_found']);
        Db::getInstance()->insert('ntsupport_message',['id_ticket'=>(int)$t['id_ticket'],'sender_type'=>'customer','sender_name'=>pSQL(Tools::getValue('contact_name',$t['contact_name'])),'message'=>pSQL($msg,true),'created_at'=>date('Y-m-d H:i:s')]);
        Db::getInstance()->update('ntsupport_ticket',['status'=>'open','updated_at'=>date('Y-m-d H:i:s')],'id_ticket='.(int)$t['id_ticket']);
        $this->out(200,['ok'=>true]);
    }

    private function ticketDetail()
    {
        $no=trim((string)Tools::getValue('ticket_no'));
        $t=Db::getInstance()->getRow(
            'SELECT id_ticket,ticket_no,status,subject,updated_at FROM `'._DB_PREFIX_.'ntsupport_ticket`
             WHERE ticket_no="'.pSQL($no).'"'
        );
        if(!$t) $this->out(404,['ok'=>false,'error'=>'ticket_not_found']);

        $messages=Db::getInstance()->executeS(
            'SELECT id_message,sender_type,sender_name,message,created_at
             FROM `'._DB_PREFIX_.'ntsupport_message`
             WHERE id_ticket='.(int)$t['id_ticket'].' ORDER BY id_message ASC'
        );

        $this->out(200,['ok'=>true,'ticket'=>$t,'messages'=>$messages]);
    }

    private function ticketStatus()
    {
        $no=trim((string)Tools::getValue('ticket_no'));
        $t=Db::getInstance()->getRow('SELECT ticket_no,status,updated_at FROM `'._DB_PREFIX_.'ntsupport_ticket` WHERE ticket_no="'.pSQL($no).'"');
        if(!$t) $this->out(404,['ok'=>false,'error'=>'ticket_not_found']);
        $this->out(200,['ok'=>true,'ticket'=>$t]);
    }

    private function out($code,$data){http_response_code($code);die(json_encode($data,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES));}
}
