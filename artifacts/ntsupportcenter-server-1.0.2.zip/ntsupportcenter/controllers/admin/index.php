<?php
header('Location: ../');
exit;
