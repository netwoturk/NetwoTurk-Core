<?php
class AdminNtSupportCenterController extends ModuleAdminController
{
    public function __construct(){ $this->bootstrap=true; parent::__construct(); }

    public function initContent()
    {
        parent::initContent();
        if(Tools::isSubmit('ntsc_download')) $this->downloadAttachment();
        if(Tools::isSubmit('ntsc_answer')) $this->saveAnswer();
        if(Tools::isSubmit('ntsc_status')) $this->saveStatus();

        $id=(int)Tools::getValue('id_ticket');
        if($id){
            $ticket=Db::getInstance()->getRow('SELECT * FROM `'._DB_PREFIX_.'ntsupport_ticket` WHERE id_ticket='.$id);
            $messages=Db::getInstance()->executeS('SELECT * FROM `'._DB_PREFIX_.'ntsupport_message` WHERE id_ticket='.$id.' ORDER BY created_at ASC,id_message ASC');
            $attachments=Db::getInstance()->executeS('SELECT * FROM `'._DB_PREFIX_.'ntsupport_attachment` WHERE id_ticket='.$id.' ORDER BY id_attachment ASC');
            $this->context->smarty->assign(['list_mode'=>false,'ticket'=>$ticket,'messages'=>$messages,'attachments'=>$attachments]);
        }else{
            $tickets=Db::getInstance()->executeS('SELECT * FROM `'._DB_PREFIX_.'ntsupport_ticket` ORDER BY updated_at DESC LIMIT 500');
            $stats=[];
            foreach(['open','reviewing','waiting_customer','answered','resolved'] as $s)
                $stats[$s]=(int)Db::getInstance()->getValue('SELECT COUNT(*) FROM `'._DB_PREFIX_.'ntsupport_ticket` WHERE status="'.pSQL($s).'"');
            $this->context->smarty->assign(['list_mode'=>true,'tickets'=>$tickets,'stats'=>$stats]);
        }
        $this->context->smarty->assign('self_url',$this->context->link->getAdminLink('AdminNtSupportCenter'));
        $this->setTemplate('dashboard.tpl');
    }

    private function downloadAttachment()
    {
        $id=(int)Tools::getValue('id_attachment');
        $a=Db::getInstance()->getRow('SELECT * FROM `'._DB_PREFIX_.'ntsupport_attachment` WHERE id_attachment='.$id);
        if(!$a) return;
        $file=_PS_MODULE_DIR_.'ntsupportcenter/private_uploads/'.basename($a['stored_name']);
        if(!is_file($file)) return;
        header('Content-Type: '.$a['mime_type']);
        header('Content-Length: '.filesize($file));
        header('Content-Disposition: attachment; filename="'.str_replace('"','',basename($a['original_name'])).'"');
        readfile($file);
        exit;
    }

    private function saveAnswer()
    {
        $id=(int)Tools::getValue('id_ticket'); $answer=trim((string)Tools::getValue('answer'));
        if(!$id || $answer==='') return;
        $t=Db::getInstance()->getRow('SELECT * FROM `'._DB_PREFIX_.'ntsupport_ticket` WHERE id_ticket='.$id);
        if(!$t) return;
        $name=trim($this->context->employee->firstname.' '.$this->context->employee->lastname);
        Db::getInstance()->insert('ntsupport_message',['id_ticket'=>$id,'sender_type'=>'support','sender_name'=>pSQL($name),'message'=>pSQL($answer,true),'created_at'=>date('Y-m-d H:i:s')]);
        Db::getInstance()->update('ntsupport_ticket',['status'=>'answered','updated_at'=>date('Y-m-d H:i:s')],'id_ticket='.$id);
        $this->module->sendCustomerAnswerMail($t,$answer);
        $this->confirmations[]='Cevap kaydedildi. Müşteri e-postası mevcutsa bildirim gönderildi.';
    }

    private function saveStatus()
    {
        $id=(int)Tools::getValue('id_ticket'); $s=(string)Tools::getValue('status');
        if($id && in_array($s,['open','reviewing','waiting_customer','answered','resolved'],true))
            Db::getInstance()->update('ntsupport_ticket',['status'=>pSQL($s),'updated_at'=>date('Y-m-d H:i:s')],'id_ticket='.$id);
    }
}
