<?php
class AdminNtSupportRootController extends ModuleAdminController {}
