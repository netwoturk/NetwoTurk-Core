<link rel="stylesheet" href="{$smarty.const.__PS_BASE_URI__|escape:'htmlall':'UTF-8'}modules/ntsupportcenter/views/css/admin.css">
<div class="ntsc">
 <div class="ntsc-hero"><div><h2>NetwoTürk Destek Merkezi</h2><p>Tüm müşteriler ve yazılımlar için merkezi destek yönetimi</p></div></div>
 {if $list_mode}
 <div class="ntsc-kpis">
  <div><b>{$stats.open|intval}</b><span>Açık</span></div><div><b>{$stats.reviewing|intval}</b><span>İnceleniyor</span></div>
  <div><b>{$stats.waiting_customer|intval}</b><span>Müşteri Bekleniyor</span></div><div><b>{$stats.answered|intval}</b><span>Cevaplandı</span></div>
  <div><b>{$stats.resolved|intval}</b><span>Çözüldü</span></div>
 </div>
 <div class="panel ntsc-panel"><div class="table-responsive"><table class="table"><thead><tr><th>Ticket</th><th>Firma / Domain</th><th>Ürün</th><th>Konu</th><th>Öncelik</th><th>Durum</th><th>E-posta</th><th>Güncelleme</th></tr></thead><tbody>
 {foreach $tickets as $t}<tr>
 <td><a href="{$self_url|escape:'htmlall':'UTF-8'}&id_ticket={$t.id_ticket|intval}"><b>{$t.ticket_no|escape:'htmlall':'UTF-8'}</b></a></td>
 <td><b>{$t.company|escape:'htmlall':'UTF-8'}</b><small>{$t.domain|escape:'htmlall':'UTF-8'}</small></td>
 <td>{$t.product_name|escape:'htmlall':'UTF-8'}</td><td>{$t.subject|escape:'htmlall':'UTF-8'}</td><td>{$t.priority|escape:'htmlall':'UTF-8'}</td>
 <td><span class="ntsc-pill">{$t.status|escape:'htmlall':'UTF-8'}</span></td><td>{if $t.notify_mail_sent}<b style="color:#238b78">Gönderildi</b>{else}<b style="color:#c44343">Gönderilemedi</b>{/if}</td><td>{$t.updated_at|escape:'htmlall':'UTF-8'}</td></tr>
 {foreachelse}<tr><td colspan="8" class="text-center">Henüz destek talebi yok.</td></tr>{/foreach}
 </tbody></table></div></div>
 {else}
 <a class="btn btn-default" href="{$self_url|escape:'htmlall':'UTF-8'}">← Taleplere dön</a>
 <div class="panel ntsc-panel ntsc-detail"><h3>{$ticket.ticket_no|escape:'htmlall':'UTF-8'} — {$ticket.subject|escape:'htmlall':'UTF-8'}</h3>
 <div class="ntsc-meta"><b>{$ticket.company|escape:'htmlall':'UTF-8'}</b> · {$ticket.domain|escape:'htmlall':'UTF-8'} · {$ticket.product_name|escape:'htmlall':'UTF-8'}<br>{$ticket.contact_name|escape:'htmlall':'UTF-8'} · {$ticket.contact_phone|escape:'htmlall':'UTF-8'} · {$ticket.contact_email|escape:'htmlall':'UTF-8'}</div>
 {foreach $messages as $m}<div class="ntsc-msg {$m.sender_type|escape:'htmlall':'UTF-8'}"><b>{$m.sender_name|escape:'htmlall':'UTF-8'}</b><small>{$m.created_at|escape:'htmlall':'UTF-8'}</small><p>{$m.message|escape:'htmlall':'UTF-8'|nl2br}</p></div>{/foreach}
 {if !empty($attachments)}<div class="ntsc-files"><b>Ekler</b>{foreach $attachments as $a}<a class="btn btn-default btn-sm" href="{$self_url|escape:'htmlall':'UTF-8'}&ntsc_download=1&id_attachment={$a.id_attachment|intval}">📎 {$a.original_name|escape:'htmlall':'UTF-8'}</a>{/foreach}</div>{/if}
 <form method="post"><input type="hidden" name="id_ticket" value="{$ticket.id_ticket|intval}"><div class="form-group"><label>Cevap</label><textarea class="form-control" rows="5" name="answer" required></textarea></div><button class="btn btn-primary" name="ntsc_answer" value="1">Cevabı Gönder</button></form>
 <hr><form method="post" class="form-inline"><input type="hidden" name="id_ticket" value="{$ticket.id_ticket|intval}"><select class="form-control" name="status"><option value="open">Açık</option><option value="reviewing">İnceleniyor</option><option value="waiting_customer">Müşteri Bekleniyor</option><option value="answered">Cevaplandı</option><option value="resolved">Çözüldü</option></select> <button class="btn btn-default" name="ntsc_status" value="1">Durumu Güncelle</button></form>
 </div>
 {/if}
</div>
