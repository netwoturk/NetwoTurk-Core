<?php
if (!defined('_PS_VERSION_')) { exit; }

class NtSupportCenter extends Module
{
    public function __construct()
    {
        $this->name='ntsupportcenter';
        $this->tab='administration';
        $this->version='1.0.2';
        $this->author='NetwoTürk';
        $this->need_instance=0;
        $this->bootstrap=true;
        parent::__construct();
        $this->displayName=$this->l('NetwoTürk Destek Merkezi');
        $this->description=$this->l('Merkezi destek talebi, API ve bildirim sistemi.');
        $this->ps_versions_compliancy=['min'=>'8.0.0','max'=>'8.99.99'];
    }

    public function install()
    {
        return parent::install()
            && $this->installDb()
            && $this->installTabs()
            && $this->registerHook('displayBackOfficeTop')
            && Configuration::updateValue('NTSC_NOTIFY_EMAIL','destek@netwoturk.com')
            && Configuration::updateValue('NTSC_API_KEY',Tools::passwdGen(48));
    }

    public function uninstall()
    {
        // Destek kayıtlarını yanlışlıkla kaybetmemek için DB tabloları uninstall sırasında korunur.
        return $this->uninstallTabs() && parent::uninstall();
    }

    private function installDb()
    {
        $queries=[
        'CREATE TABLE IF NOT EXISTS `'._DB_PREFIX_.'ntsupport_ticket` (
            `id_ticket` INT UNSIGNED NOT NULL AUTO_INCREMENT,
            `ticket_no` VARCHAR(40) NOT NULL,
            `company` VARCHAR(190) NOT NULL,
            `product_name` VARCHAR(190) NOT NULL DEFAULT "",
            `domain` VARCHAR(190) NOT NULL,
            `license_id` VARCHAR(190) NOT NULL DEFAULT "",
            `contact_name` VARCHAR(190) NOT NULL,
            `contact_phone` VARCHAR(60) NOT NULL DEFAULT "",
            `contact_email` VARCHAR(190) NOT NULL DEFAULT "",
            `category` VARCHAR(100) NOT NULL DEFAULT "Genel",
            `priority` VARCHAR(20) NOT NULL DEFAULT "normal",
            `subject` VARCHAR(255) NOT NULL,
            `status` VARCHAR(30) NOT NULL DEFAULT "open",
            `source` VARCHAR(60) NOT NULL DEFAULT "api",
            `notify_mail_sent` TINYINT(1) NOT NULL DEFAULT 0,
            `created_at` DATETIME NOT NULL,
            `updated_at` DATETIME NOT NULL,
            PRIMARY KEY (`id_ticket`), UNIQUE KEY `ticket_no` (`ticket_no`),
            KEY `status` (`status`), KEY `domain` (`domain`)
        ) ENGINE='._MYSQL_ENGINE_.' DEFAULT CHARSET=utf8mb4',
        'CREATE TABLE IF NOT EXISTS `'._DB_PREFIX_.'ntsupport_message` (
            `id_message` INT UNSIGNED NOT NULL AUTO_INCREMENT,
            `id_ticket` INT UNSIGNED NOT NULL,
            `sender_type` VARCHAR(20) NOT NULL,
            `sender_name` VARCHAR(190) NOT NULL,
            `message` MEDIUMTEXT NOT NULL,
            `created_at` DATETIME NOT NULL,
            PRIMARY KEY (`id_message`), KEY `id_ticket` (`id_ticket`)
        ) ENGINE='._MYSQL_ENGINE_.' DEFAULT CHARSET=utf8mb4',
        'CREATE TABLE IF NOT EXISTS `'._DB_PREFIX_.'ntsupport_attachment` (
            `id_attachment` INT UNSIGNED NOT NULL AUTO_INCREMENT,
            `id_ticket` INT UNSIGNED NOT NULL,
            `id_message` INT UNSIGNED NOT NULL DEFAULT 0,
            `stored_name` VARCHAR(190) NOT NULL,
            `original_name` VARCHAR(255) NOT NULL,
            `mime_type` VARCHAR(100) NOT NULL,
            `file_size` INT UNSIGNED NOT NULL DEFAULT 0,
            `created_at` DATETIME NOT NULL,
            PRIMARY KEY (`id_attachment`), KEY `id_ticket` (`id_ticket`)
        ) ENGINE='._MYSQL_ENGINE_.' DEFAULT CHARSET=utf8mb4'
        ];
        foreach($queries as $sql) if(!Db::getInstance()->execute($sql)) return false;
        return true;
    }

    private function installTabs()
    {
        $parent=new Tab();
        $parent->active=1; $parent->class_name='AdminNtSupportRoot'; $parent->module=$this->name; $parent->id_parent=0;
        foreach(Language::getLanguages(false) as $l) $parent->name[(int)$l['id_lang']]='NetwoTürk Destek';
        if(!$parent->add()) return false;

        $tab=new Tab();
        $tab->active=1; $tab->class_name='AdminNtSupportCenter'; $tab->module=$this->name; $tab->id_parent=(int)$parent->id;
        foreach(Language::getLanguages(false) as $l) $tab->name[(int)$l['id_lang']]='Destek Talepleri';
        return $tab->add();
    }

    private function uninstallTabs()
    {
        foreach(['AdminNtSupportCenter','AdminNtSupportRoot'] as $c){
            $id=(int)Tab::getIdFromClassName($c);
            if($id){$t=new Tab($id);$t->delete();}
        }
        return true;
    }

    public function getContent()
    {
        if(Tools::isSubmit('submitNtSupportTestMail')){
            $this->context->smarty->assign('ntsc_test_result', $this->sendTestMail() ? 'ok' : 'fail');
        }
        if(Tools::isSubmit('submitNtSupportSettings')){
            $email=trim((string)Tools::getValue('NTSC_NOTIFY_EMAIL'));
            if(Validate::isEmail($email)) Configuration::updateValue('NTSC_NOTIFY_EMAIL',$email);
            if(Tools::getValue('regen_key')) Configuration::updateValue('NTSC_API_KEY',Tools::passwdGen(48));
            $this->context->smarty->assign('saved',true);
        }
        $this->context->smarty->assign([
            'email'=>Configuration::get('NTSC_NOTIFY_EMAIL'),
            'api_key'=>Configuration::get('NTSC_API_KEY'),
        ]);
        return $this->display(__FILE__,'views/templates/admin/configure.tpl');
    }

    public function hookDisplayBackOfficeTop($params)
    {
        // İzole ve fail-safe: burada oluşabilecek hata BO'yu veya başka modülü durdurmaz.
        try{
            $idTab=(int)Tab::getIdFromClassName('AdminNtSupportCenter');
            if(!$idTab || !$this->context->employee || !$this->context->employee->id) return '';
            if(method_exists($this->context->employee,'can') && !$this->context->employee->can('read',$idTab)) return '';
            $count=(int)Db::getInstance()->getValue('SELECT COUNT(*) FROM `'._DB_PREFIX_.'ntsupport_ticket` WHERE status IN ("open","reviewing")');
            $url=$this->context->link->getAdminLink('AdminNtSupportCenter');
            $badge=$count?'<span style="background:#dc3545;color:#fff;border-radius:12px;padding:1px 7px;margin-left:6px;font-weight:700">'.$count.'</span>':'';
            return '<a href="'.htmlspecialchars($url,ENT_QUOTES,'UTF-8').'" style="display:inline-flex;align-items:center;height:36px;padding:0 13px;margin:7px 5px;border-radius:8px;background:#003B53;color:#fff;text-decoration:none;font-weight:600;box-shadow:0 2px 7px rgba(0,59,83,.18)">Destek'.$badge.'</a>';
        }catch(Throwable $e){return '';}
    }

    public function makeTicketNo($id)
    {
        return 'NT-DST-'.date('Y').'-'.str_pad((string)$id,6,'0',STR_PAD_LEFT);
    }

    public function sendNewTicketMail(array $t,$message)
    {
        $to=(string)Configuration::get('NTSC_NOTIFY_EMAIL');
        if(!Validate::isEmail($to)) return false;

        $ok=false;
        try {
            $ok=(bool)Mail::Send(
                (int)Configuration::get('PS_LANG_DEFAULT'),
                'new_ticket',
                '[Yeni Destek Talebi '.$t['ticket_no'].'] '.$t['company'].' - '.$t['subject'],
                [
                    '{ticket_no}'=>$t['ticket_no'],
                    '{company}'=>$t['company'],
                    '{domain}'=>$t['domain'],
                    '{product}'=>$t['product_name'],
                    '{contact}'=>$t['contact_name'],
                    '{phone}'=>$t['contact_phone'],
                    '{subject}'=>$t['subject'],
                    '{message}'=>$message
                ],
                $to,
                'NetwoTürk Destek',
                null,
                null,
                null,
                null,
                _PS_MODULE_DIR_.$this->name.'/mails/'
            );
        } catch (Throwable $e) {
            PrestaShopLogger::addLog('ntsupportcenter new ticket mail: '.$e->getMessage(),3);
        }

        if(isset($t['id_ticket'])) {
            Db::getInstance()->update(
                'ntsupport_ticket',
                ['notify_mail_sent'=>(int)$ok],
                'id_ticket='.(int)$t['id_ticket']
            );
        }

        if(!$ok) {
            PrestaShopLogger::addLog('ntsupportcenter: Yeni ticket maili gönderilemedi: '.$to,3);
        }
        return $ok;
    }

    public function sendCustomerAnswerMail(array $t,$answer)
    {
        if(!Validate::isEmail($t['contact_email'])) return true;
        return Mail::Send((int)Configuration::get('PS_LANG_DEFAULT'),'ticket_answered',
            'Destek talebiniz cevaplandı - '.$t['ticket_no'],
            ['{ticket_no}'=>$t['ticket_no'],'{company}'=>$t['company'],'{subject}'=>$t['subject'],'{answer}'=>$answer],
            $t['contact_email'],$t['contact_name'],null,null,null,null,_PS_MODULE_DIR_.$this->name.'/mails/');
    }
    public function sendTestMail()
    {
        $to=(string)Configuration::get('NTSC_NOTIFY_EMAIL');
        if(!Validate::isEmail($to)) return false;
        try {
            return (bool)Mail::Send(
                (int)Configuration::get('PS_LANG_DEFAULT'),
                'test_mail',
                'NetwoTürk Destek Merkezi - Test E-postası',
                ['{message}'=>'Bu e-posta NetwoTürk Destek Merkezi test gönderimidir.'],
                $to,
                'NetwoTürk Destek',
                null,
                null,
                null,
                null,
                _PS_MODULE_DIR_.$this->name.'/mails/'
            );
        } catch (Throwable $e) {
            PrestaShopLogger::addLog('ntsupportcenter test mail: '.$e->getMessage(),3);
            return false;
        }
    }

}
