<?php
if (!defined('_PS_VERSION_')) { exit; }

function upgrade_module_1_0_3($module)
{
    $table = '`'._DB_PREFIX_.'ntsupport_client_ticket`';

    $cols = Db::getInstance()->executeS('SHOW COLUMNS FROM '.$table.' LIKE "last_support_message_id"');
    if (!$cols) {
        if (!Db::getInstance()->execute(
            'ALTER TABLE '.$table.' ADD `last_support_message_id` INT UNSIGNED NOT NULL DEFAULT 0 AFTER `last_seen_message_id`'
        )) {
            return false;
        }
    }

    $cols = Db::getInstance()->executeS('SHOW COLUMNS FROM '.$table.' LIKE "last_seen_support_message_id"');
    if (!$cols) {
        if (!Db::getInstance()->execute(
            'ALTER TABLE '.$table.' ADD `last_seen_support_message_id` INT UNSIGNED NOT NULL DEFAULT 0 AFTER `last_support_message_id`'
        )) {
            return false;
        }
    }

    // Existing tickets start with no unread support notification.
    // Next sync will populate last_support_message_id only from sender_type=support.
    return true;
}
