<?php
if (!defined('_PS_VERSION_')) { exit; }

function upgrade_module_1_0_2($module)
{
    if (!$module->isRegisteredInHook('displayBackOfficeTop')) {
        if (!$module->registerHook('displayBackOfficeTop')) {
            return false;
        }
    }
    return true;
}
