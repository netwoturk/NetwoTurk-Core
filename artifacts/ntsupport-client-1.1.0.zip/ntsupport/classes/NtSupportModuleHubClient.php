<?php

if (!defined('_PS_VERSION_')) {
    exit;
}

final class NtSupportModuleHubClient
{
    private const ENDPOINT = 'https://netwoturktech.com/module/ntmodulehub/feed';
    private const KEY_ID = 'd767fd153ae8af3a38842e093cb2dfd2';
    private const CACHE_KEY = 'NTSUPPORT_MODULE_HUB_CACHE';
    private const MAX_BODY_BYTES = 1048576;
    private const MAX_STALE_SECONDS = 604800;
    private const PUBLIC_KEY = <<<'PEM'
-----BEGIN PUBLIC KEY-----
MIIBojANBgkqhkiG9w0BAQEFAAOCAY8AMIIBigKCAYEAslBCd8ngNvFg7XhKpNKn
QhJKCDeiVjfUH1Qvlr/cli0jiqdHVoB8VE/3SFDL334qieI3h4Nvu/8EVYOjXD/n
BpBtVlY//mME/JnXgiZR2/pioGGBCNtKM+RP65F296LF0lxKIjDuQz2StOzKbGEA
VXi1pAyR2IeDkvMF8Zy7Mv5d0Y/giNcapMf3oQlsgEIZgd/TJLq9qqofNLaXYOfq
gXnNlUcQeq3rqh1kYFdix0xOzjJxggH+h+9zs1POsgtSqY7uzywn0Pdgu5z3Q5iU
2D009bD6nwlqTCycgBxCi4MTlLqAjmiqPf5Rw+VSfBXhS2bh5SU4AO5DBbLCOKxA
I8QdRXZOezsntfgyX4oltOOD3q8xiX37A7nZFylxCrtlBDJWJpp3w7K7W7TLQsz/
14XQ275ANrSfvQkXQyDr9UkUlzhrJwBXjA6/Waov8fgxhP0UllEkJwy/qt0gOaJh
OWxmjZ76fq2RTyGHFLzwOS0Kau854Ly2aHCHje4BblKnAgMBAAE=
-----END PUBLIC KEY-----
PEM;

    public function getProducts()
    {
        try {
            $payload = $this->loadPayload();
            if (!is_array($payload) || ($payload['schema'] ?? '') !== 'netwoturk.module-hub.v1' || !is_array($payload['products'] ?? null)) {
                return array();
            }
            $products = array();
            foreach ($payload['products'] as $product) {
                if (!is_array($product) || !$this->isCompatible($product)) {
                    continue;
                }
                $name = trim(strip_tags((string) ($product['name'] ?? '')));
                $salesUrl = $this->allowedUrl((string) ($product['sales_url'] ?? ''), array('netwoturk.com', 'www.netwoturk.com'));
                $imageUrl = $this->allowedUrl((string) ($product['image_url'] ?? ''), array('netwoturktech.com', 'www.netwoturktech.com'));
                if ($name === '' || $salesUrl === '' || $imageUrl === '') {
                    continue;
                }
                $products[] = array(
                    'product_code' => $this->shortText((string) ($product['product_code'] ?? ''), 100),
                    'name' => $this->shortText($name, 120),
                    'summary' => $this->shortText(trim(strip_tags((string) ($product['summary'] ?? ''))), 300),
                    'image_url' => $imageUrl,
                    'sales_url' => $salesUrl,
                    'compatibility' => 'PrestaShop ' . _PS_VERSION_ . ' ile uyumlu',
                    'sort_order' => (int) ($product['sort_order'] ?? 0),
                );
            }
            usort($products, static function ($a, $b) { return $a['sort_order'] <=> $b['sort_order']; });
            return $products;
        } catch (Throwable $e) {
            return array();
        }
    }

    private function loadPayload()
    {
        $cached = $this->readCache();
        $ttl = $cached ? max(300, min(21600, (int) ($cached['ttl'] ?? 21600))) : 0;
        if ($cached && time() - (int) $cached['cached_at'] <= $ttl && $this->verify($cached['body'], $cached['signature'], $cached['key_id'])) {
            return json_decode($cached['body'], true);
        }

        $module = Module::getInstanceByName('ntsupport');
        $query = http_build_query(array(
            'product_code' => 'ntsupport',
            'module_version' => $module ? (string) $module->version : '',
            'prestashop_version' => _PS_VERSION_,
        ), '', '&');
        $response = $this->request(self::ENDPOINT . '?' . $query);
        if ($response && $this->verify($response['body'], $response['signature'], $response['key_id'])) {
            $payload = json_decode($response['body'], true);
            if (is_array($payload) && ($payload['schema'] ?? '') === 'netwoturk.module-hub.v1') {
                $ttl = !empty($payload['products']) ? max(300, min(21600, (int) ($payload['cache_ttl'] ?? 21600))) : 300;
                Configuration::updateValue(self::CACHE_KEY, json_encode(array(
                    'body' => $response['body'],
                    'signature' => $response['signature'],
                    'key_id' => $response['key_id'],
                    'ttl' => $ttl,
                    'cached_at' => time(),
                ), JSON_UNESCAPED_SLASHES));
                return $payload;
            }
        }

        if ($cached && time() - (int) $cached['cached_at'] <= self::MAX_STALE_SECONDS && $this->verify($cached['body'], $cached['signature'], $cached['key_id'])) {
            return json_decode($cached['body'], true);
        }
        return array();
    }

    private function request($url)
    {
        $headers = array();
        $body = '';
        if (function_exists('curl_init')) {
            $curl = curl_init($url);
            curl_setopt_array($curl, array(
                CURLOPT_RETURNTRANSFER => false,
                CURLOPT_FOLLOWLOCATION => false,
                CURLOPT_CONNECTTIMEOUT => 2,
                CURLOPT_TIMEOUT => 4,
                CURLOPT_PROTOCOLS => CURLPROTO_HTTPS,
                CURLOPT_HTTPHEADER => array('Accept: application/json'),
                CURLOPT_USERAGENT => 'NetwoTurk-ntsupport/' . _PS_VERSION_,
                CURLOPT_HEADERFUNCTION => static function ($curl, $line) use (&$headers) {
                    $parts = explode(':', $line, 2);
                    if (count($parts) === 2) {
                        $headers[strtolower(trim($parts[0]))] = trim($parts[1]);
                    }
                    return strlen($line);
                },
                CURLOPT_WRITEFUNCTION => static function ($curl, $chunk) use (&$body) {
                    if (strlen($body) + strlen($chunk) > self::MAX_BODY_BYTES) {
                        return 0;
                    }
                    $body .= $chunk;
                    return strlen($chunk);
                },
            ));
            $ok = curl_exec($curl);
            $status = (int) curl_getinfo($curl, CURLINFO_HTTP_CODE);
            curl_close($curl);
            if ($ok === false || $status !== 200) {
                return null;
            }
        } else {
            $context = stream_context_create(array('http' => array(
                'timeout' => 4,
                'ignore_errors' => true,
                'follow_location' => 0,
                'header' => "Accept: application/json\r\n",
            )));
            $body = @file_get_contents($url, false, $context, 0, self::MAX_BODY_BYTES + 1);
            foreach (($http_response_header ?? array()) as $line) {
                $parts = explode(':', $line, 2);
                if (count($parts) === 2) {
                    $headers[strtolower(trim($parts[0]))] = trim($parts[1]);
                }
            }
            if (!is_string($body) || strlen($body) > self::MAX_BODY_BYTES || !preg_match('#^HTTP/\S+ 200(?:\s|$)#', (string) (($http_response_header ?? array())[0] ?? ''))) {
                return null;
            }
        }
        return array(
            'body' => $body,
            'signature' => (string) ($headers['x-nt-signature'] ?? ''),
            'key_id' => (string) ($headers['x-nt-key-id'] ?? ''),
        );
    }

    private function verify($body, $signature, $keyId)
    {
        if ($body === '' || $signature === '' || !hash_equals(self::KEY_ID, (string) $keyId) || !function_exists('openssl_verify')) {
            return false;
        }
        $decoded = base64_decode($signature, true);
        return $decoded !== false && openssl_verify($body, $decoded, self::PUBLIC_KEY, OPENSSL_ALGO_SHA256) === 1;
    }

    private function readCache()
    {
        $cache = json_decode((string) Configuration::get(self::CACHE_KEY), true);
        return is_array($cache) && isset($cache['body'], $cache['signature'], $cache['key_id'], $cache['cached_at']) ? $cache : null;
    }

    private function allowedUrl($url, array $hosts)
    {
        if (!filter_var($url, FILTER_VALIDATE_URL) || strtolower((string) parse_url($url, PHP_URL_SCHEME)) !== 'https') {
            return '';
        }
        return in_array(strtolower((string) parse_url($url, PHP_URL_HOST)), $hosts, true) ? $url : '';
    }

    private function isCompatible(array $product)
    {
        $minimum = trim((string) ($product['ps_min'] ?? ''));
        $maximum = trim((string) ($product['ps_max'] ?? ''));
        return ($minimum === '' || version_compare(_PS_VERSION_, $minimum, '>='))
            && ($maximum === '' || version_compare(_PS_VERSION_, $maximum, '<='));
    }

    private function shortText($value, $length)
    {
        return function_exists('mb_substr') ? mb_substr((string) $value, 0, $length) : substr((string) $value, 0, $length);
    }
}
