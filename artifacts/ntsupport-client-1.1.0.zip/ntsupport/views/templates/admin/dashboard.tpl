<div class="ntsupport">
  <div class="ntsupport-hero">
    <div>
      <span>NETWOTÜRK DESTEK</span>
      <h2>Destek Merkezi</h2>
      <p>Destek taleplerinizi oluşturun, NetwoTürk yanıtlarını takip edin ve aynı ticket üzerinden mesajlaşın.</p>
    </div>
    <div class="ntsupport-state {if $ntsupport_ready}ok{else}wait{/if}">
      {if $ntsupport_ready}Bağlı{else}Kurulum Gerekli{/if}
    </div>
  </div>

  {if $ntsupport_notice}
    <div class="alert alert-{$ntsupport_notice.type|escape:'htmlall':'UTF-8'}">{$ntsupport_notice.text|escape:'htmlall':'UTF-8'}</div>
  {/if}

  {if !$ntsupport_ready}
    <div class="panel ntsupport-warning">
      Destek bağlantısı henüz tamamlanmamış.
      <a class="btn btn-primary" href="{$ntsupport_config|escape:'htmlall':'UTF-8'}">Bağlantıyı Yapılandır</a>
    </div>
  {else}
    <div class="ntsupport-grid">
      <div class="panel ntsupport-card">
        <h3>Yeni Destek Talebi</h3>
        <div class="ntsupport-auto">
          <div><span>Firma</span><b>{$ntsupport_company|escape:'htmlall':'UTF-8'}</b></div>
          <div><span>Domain</span><b>{$ntsupport_domain|escape:'htmlall':'UTF-8'}</b></div>
          <div><span>Talebi Açan</span><b>{$ntsupport_employee|escape:'htmlall':'UTF-8'}</b></div>
        </div>

        <form method="post" enctype="multipart/form-data">
          <div class="ntsupport-form-grid">
            <div>
              <label>Ürün / Hizmet</label>
              <select class="form-control" name="support_product">
                <option>NetwoTürk Emlak Sistemi</option>
                <option>NetwoTürk E-Fatura</option>
                <option>Pazaryeri Entegrasyonu</option>
                <option>Web / E-Ticaret</option>
                <option>Diğer</option>
              </select>
            </div>
            <div>
              <label>Kategori</label>
              <select class="form-control" name="support_category">
                <option>Genel</option><option>Teknik Hata</option><option>İlan / Portföy</option>
                <option>CRM</option><option>Kira Yönetimi</option><option>Muhasebe / Hakediş</option><option>Diğer</option>
              </select>
            </div>
            <div>
              <label>Öncelik</label>
              <select class="form-control" name="support_priority">
                <option value="normal">Normal</option><option value="high">Yüksek</option>
                <option value="urgent">Acil</option><option value="low">Düşük</option>
              </select>
            </div>
            <div>
              <label>İrtibat Numarası *</label>
              <input class="form-control" name="support_phone" required>
            </div>
            <div>
              <label>E-posta</label>
              <input class="form-control" type="email" name="support_email" value="{$ntsupport_employee_email|escape:'htmlall':'UTF-8'}">
            </div>
            <div>
              <label>Ekran Görüntüsü</label>
              <input type="file" name="support_attachment" accept=".jpg,.jpeg,.png,.webp,image/jpeg,image/png,image/webp">
            </div>
          </div>

          <div class="form-group">
            <label>Konu *</label>
            <input class="form-control" name="support_subject" maxlength="255" required>
          </div>
          <div class="form-group">
            <label>Destek Talebi Açıklaması *</label>
            <textarea class="form-control" name="support_message" rows="5" required></textarea>
          </div>
          <button class="btn btn-primary pull-right" name="ntsupport_create" value="1">
            Destek Talebi Gönder
          </button>
          <div class="clearfix"></div>
        </form>
      </div>

      <div class="panel ntsupport-card">
        <h3>Destek Taleplerim</h3>
        {if empty($ntsupport_tickets)}
          <div class="ntsupport-empty">Henüz destek talebi yok.</div>
        {else}
          <div class="ntsupport-ticket-list">
            {foreach $ntsupport_tickets as $t}
              <a class="ntsupport-ticket {if $t.unread}unread{/if}"
                 href="{$ntsupport_self|escape:'htmlall':'UTF-8'}&ticket_no={$t.ticket_no|escape:'url':'UTF-8'}">
                <div>
                  <b>{$t.ticket_no|escape:'htmlall':'UTF-8'}</b>
                  <span>{$t.subject|escape:'htmlall':'UTF-8'}</span>
                </div>
                <div class="ntsupport-ticket-right">
                  {if $t.unread}<em>Yeni Cevap</em>{/if}
                  <small>{$t.status|escape:'htmlall':'UTF-8'}</small>
                </div>
              </a>
            {/foreach}
          </div>
        {/if}
      </div>
    </div>

    {if $ntsupport_selected}
      <div class="panel ntsupport-conversation">
        <div class="ntsupport-conversation-head">
          <div>
            <span>{$ntsupport_selected.ticket_no|escape:'htmlall':'UTF-8'}</span>
            <h3>{$ntsupport_selected.subject|escape:'htmlall':'UTF-8'}</h3>
          </div>
          <b>{$ntsupport_selected.status|escape:'htmlall':'UTF-8'}</b>
        </div>

        <div class="ntsupport-messages">
          {foreach $ntsupport_selected.messages as $m}
            <div class="ntsupport-message {$m.sender_type|escape:'htmlall':'UTF-8'}">
              <div>
                <b>{$m.sender_name|escape:'htmlall':'UTF-8'}</b>
                <small>{$m.created_at|escape:'htmlall':'UTF-8'}</small>
              </div>
              <p>{$m.message|escape:'htmlall':'UTF-8'|nl2br}</p>
            </div>
          {/foreach}
        </div>

        <form method="post" class="ntsupport-reply">
          <input type="hidden" name="ticket_no" value="{$ntsupport_selected.ticket_no|escape:'htmlall':'UTF-8'}">
          <label>Yanıt Yaz</label>
          <textarea class="form-control" name="reply_message" rows="4" required></textarea>
          <button class="btn btn-primary" name="ntsupport_reply" value="1">Yanıtı Gönder</button>
        </form>
      </div>
    {/if}
  {/if}

  {if !empty($ntsupport_hub_products)}
    <section class="panel ntsupport-hub" aria-labelledby="ntsupport-hub-title">
      <div class="panel-heading">
        <span id="ntsupport-hub-title">NetwoTürk Modülleri</span>
        <span class="ntsupport-hub-controls">
          <button type="button" class="btn btn-default" aria-label="Önceki ürün" onclick="document.getElementById('ntsupport-hub-track').scrollBy({ left: -330, behavior: 'smooth' })">‹</button>
          <button type="button" class="btn btn-default" aria-label="Sonraki ürün" onclick="document.getElementById('ntsupport-hub-track').scrollBy({ left: 330, behavior: 'smooth' })">›</button>
        </span>
      </div>
      <div id="ntsupport-hub-track" class="ntsupport-hub-track" tabindex="0">
        {foreach $ntsupport_hub_products as $product}
          <article class="ntsupport-hub-card">
            <div class="ntsupport-hub-image"><img loading="lazy" src="{$product.image_url|escape:'htmlall':'UTF-8'}" alt="{$product.name|escape:'htmlall':'UTF-8'}"></div>
            <div class="ntsupport-hub-body">
              <h4>{$product.name|escape:'htmlall':'UTF-8'}</h4>
              <p>{$product.summary|escape:'htmlall':'UTF-8'}</p>
              <small>{$product.compatibility|escape:'htmlall':'UTF-8'}</small>
              <a class="btn btn-primary" target="_blank" rel="noopener noreferrer" href="{$product.sales_url|escape:'htmlall':'UTF-8'}">İncele / Satın Al</a>
            </div>
          </article>
        {/foreach}
      </div>
    </section>
  {/if}
</div>
