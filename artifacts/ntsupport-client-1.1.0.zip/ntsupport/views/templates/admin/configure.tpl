<div class="panel">
  <h3>NetwoTürk Destek Bağlantısı</h3>
  <p>Bu alan yalnız sistem yöneticisi içindir. API anahtarı kullanıcı ekranında gösterilmez.</p>

  <form method="post">
    <div class="form-group">
      <label>Merkezi Destek API Adresi</label>
      <input class="form-control" name="NTSUPPORT_API_URL" value="{$ntsupport_api_url|escape:'htmlall':'UTF-8'}">
    </div>

    <div class="form-group">
      <label>Firma Adı</label>
      <input class="form-control" name="NTSUPPORT_COMPANY" value="{$ntsupport_company|escape:'htmlall':'UTF-8'}" placeholder="Örn. Teknomax İnşaat">
    </div>

    <div class="form-group">
      <label>API Anahtarı</label>
      <input class="form-control" type="password" name="NTSUPPORT_API_KEY" value=""
             placeholder="{if $ntsupport_key_saved}Kayıtlı — değiştirmek için yeni anahtar girin{else}NetwoTürk Tech API anahtarını girin{/if}">
    </div>

    <button class="btn btn-primary" name="submitNtSupportConfig" value="1">Kaydet</button>
    <a class="btn btn-default" href="{$ntsupport_panel_url|escape:'htmlall':'UTF-8'}">Destek Merkezine Git</a>
  </form>
</div>
