<?php
require_once _PS_MODULE_DIR_.'ntsupport/classes/NtSupportModuleHubClient.php';
class AdminNtSupportController extends ModuleAdminController
{
    public function __construct()
    {
        $this->bootstrap = true;
        parent::__construct();
    }

    public function setMedia($isNewTheme = false)
    {
        parent::setMedia($isNewTheme);
        $this->addCSS($this->module->getPathUri().'views/css/admin.css?v=1.1.0');
        $this->addCSS($this->module->getPathUri().'views/css/hub.css?v=1.1.0');
    }

    public function initContent()
    {
        parent::initContent();

        $notice = '';
        if (Tools::isSubmit('ntsupport_create')) {
            $notice = $this->handleCreate();
        }
        if (Tools::isSubmit('ntsupport_reply')) {
            $notice = $this->handleReply();
        }

        $rows = $this->module->syncTickets(false);
        $selectedNo = trim((string)Tools::getValue('ticket_no'));
        $selected = null;

        foreach ($rows as &$row) {
            $row['unread'] = (int)$row['last_support_message_id'] > (int)$row['last_seen_support_message_id'];
            if ($selectedNo !== '' && $row['ticket_no'] === $selectedNo) {
                $selected = $row;
            }
        }
        unset($row);

        if ($selected) {
            $this->module->markSeen($selected['ticket_no'], (int)$selected['last_message_id']);
            $this->module->markSupportSeen($selected['ticket_no'], (int)$selected['last_support_message_id']);
            $selected['unread'] = false;
        }

        $employee = $this->context->employee;
        $this->context->smarty->assign([
            'ntsupport_ready' => $this->module->isReady(),
            'ntsupport_notice' => $notice,
            'ntsupport_company' => Configuration::get('NTSUPPORT_COMPANY'),
            'ntsupport_domain' => $this->module->currentDomain(),
            'ntsupport_employee' => trim((string)$employee->firstname.' '.(string)$employee->lastname),
            'ntsupport_employee_email' => (string)$employee->email,
            'ntsupport_tickets' => $rows,
            'ntsupport_selected' => $selected,
            'ntsupport_self' => $this->context->link->getAdminLink('AdminNtSupport'),
            'ntsupport_config' => $this->context->link->getAdminLink('AdminModules', true, [], [
                'configure' => 'ntsupport',
                'module_name' => 'ntsupport',
            ]),
            'ntsupport_hub_products' => (new NtSupportModuleHubClient())->getProducts(),
        ]);

        $this->setTemplate('dashboard.tpl');
    }

    private function handleCreate()
    {
        if (!$this->module->isReady()) {
            return ['type'=>'warning','text'=>'Destek köprüsü henüz yapılandırılmadı.'];
        }

        foreach (['support_phone','support_subject','support_message'] as $required) {
            if (trim((string)Tools::getValue($required)) === '') {
                return ['type'=>'danger','text'=>'İrtibat numarası, konu ve açıklama zorunludur.'];
            }
        }

        $employee = $this->context->employee;
        $result = $this->module->createTicket([
            'product_name' => Tools::getValue('support_product', 'NetwoTürk Yazılım / Hizmet'),
            'contact_name' => trim((string)$employee->firstname.' '.(string)$employee->lastname),
            'contact_phone' => Tools::getValue('support_phone'),
            'contact_email' => Tools::getValue('support_email', $employee->email),
            'category' => Tools::getValue('support_category', 'Genel'),
            'priority' => Tools::getValue('support_priority', 'normal'),
            'subject' => Tools::getValue('support_subject'),
            'message' => Tools::getValue('support_message'),
        ], $_FILES['support_attachment'] ?? null);

        if (empty($result['ok'])) {
            return ['type'=>'danger','text'=>'Destek talebi gönderilemedi: '.($result['error'] ?? 'Bilinmeyen hata')];
        }

        return ['type'=>'success','text'=>'Destek talebiniz oluşturuldu. Talep No: '.$result['ticket_no']];
    }

    private function handleReply()
    {
        $ticketNo = trim((string)Tools::getValue('ticket_no'));
        $message = trim((string)Tools::getValue('reply_message'));
        if ($ticketNo === '' || $message === '') {
            return ['type'=>'danger','text'=>'Yanıt alanı boş bırakılamaz.'];
        }

        $result = $this->module->replyTicket($ticketNo, $message);
        if (empty($result['ok'])) {
            return ['type'=>'danger','text'=>'Yanıt gönderilemedi: '.($result['error'] ?? 'Bilinmeyen hata')];
        }
        return ['type'=>'success','text'=>'Yanıtınız NetwoTürk Destek Merkezi’ne gönderildi.'];
    }
}
