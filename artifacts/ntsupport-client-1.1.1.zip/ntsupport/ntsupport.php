<?php
if (!defined('_PS_VERSION_')) { exit; }

class NtSupport extends Module
{
    const TAB_CLASS = 'AdminNtSupport';
    const PRODUCT_CODE = 'ntsupport';
    const MODULE_FAMILY = 'netwoturk';
    const INTEGRATION_STANDARD = '1.0.0';

    public function __construct()
    {
        $this->name = 'ntsupport';
        $this->tab = 'administration';
        $this->version = '1.1.1';
        $this->author = 'NetwoTürk';
        $this->need_instance = 0;
        $this->bootstrap = true;
        parent::__construct();

        $this->displayName = $this->l('NetwoTürk Destek');
        $this->description = $this->l('NetwoTürk merkezi destek sistemine bağlı müşteri ticket modülü.');
        $this->ps_versions_compliancy = ['min' => '8.0.0', 'max' => '9.99.99'];
    }

    public function install()
    {
        return parent::install()
            && $this->installDb()
            && $this->installTab()
            && $this->registerHook('displayBackOfficeTop')
            && $this->installDefaults();
    }

    public function uninstall()
    {
        return $this->uninstallTab() && parent::uninstall();
    }

    private function installDefaults()
    {
        if (!Configuration::get('NTSUPPORT_API_URL')) {
            Configuration::updateValue('NTSUPPORT_API_URL', 'https://netwoturktech.com/module/ntsupportcenter/api');
        }
        return true;
    }

    private function installDb()
    {
        return Db::getInstance()->execute(
            'CREATE TABLE IF NOT EXISTS `'._DB_PREFIX_.'ntsupport_client_ticket` (
                `id_local` INT UNSIGNED NOT NULL AUTO_INCREMENT,
                `ticket_no` VARCHAR(40) NOT NULL,
                `subject` VARCHAR(255) NOT NULL,
                `status` VARCHAR(30) NOT NULL DEFAULT "open",
                `last_message_id` INT UNSIGNED NOT NULL DEFAULT 0,
                `last_seen_message_id` INT UNSIGNED NOT NULL DEFAULT 0,
                `last_support_message_id` INT UNSIGNED NOT NULL DEFAULT 0,
                `last_seen_support_message_id` INT UNSIGNED NOT NULL DEFAULT 0,
                `created_by_employee` INT UNSIGNED NOT NULL DEFAULT 0,
                `date_add` DATETIME NOT NULL,
                `date_upd` DATETIME NOT NULL,
                PRIMARY KEY (`id_local`),
                UNIQUE KEY `ticket_no` (`ticket_no`)
            ) ENGINE='._MYSQL_ENGINE_.' DEFAULT CHARSET=utf8mb4'
        );
    }

    private function installTab()
    {
        $parentId = (int)Tab::getIdFromClassName('AdminNtModulesRoot');
        if (!$parentId) {
            $root = new Tab();
            $root->active = 1;
            $root->class_name = 'AdminNtModulesRoot';
            $root->module = $this->name;
            $root->id_parent = 0;
            if (property_exists($root, 'icon')) {
                $root->icon = 'extension';
            }
            foreach (Language::getLanguages(false) as $lang) {
                $root->name[(int)$lang['id_lang']] = 'NetwoTürk Modülleri';
            }
            if (!$root->add()) {
                return false;
            }
            $parentId = (int)$root->id;
        }

        $tab = new Tab();
        $tab->active = 1;
        $tab->class_name = self::TAB_CLASS;
        $tab->module = $this->name;
        $tab->id_parent = $parentId;
        if (property_exists($tab, 'icon')) {
            $tab->icon = 'contact_support';
        }
        foreach (Language::getLanguages(false) as $lang) {
            $tab->name[(int)$lang['id_lang']] = 'Destek Merkezi';
        }
        return $tab->add();
    }

    private function uninstallTab()
    {
        $id = (int)Tab::getIdFromClassName(self::TAB_CLASS);
        if ($id) {
            $tab = new Tab($id);
            return (bool)$tab->delete();
        }
        return true;
    }

    public function getContent()
    {
        $out = '';
        if (Tools::isSubmit('submitNtSupportConfig')) {
            $url = trim((string)Tools::getValue('NTSUPPORT_API_URL'));
            $company = trim((string)Tools::getValue('NTSUPPORT_COMPANY'));
            $key = trim((string)Tools::getValue('NTSUPPORT_API_KEY'));

            if ($url !== '') Configuration::updateValue('NTSUPPORT_API_URL', $url);
            if ($company !== '') Configuration::updateValue('NTSUPPORT_COMPANY', $company);
            if ($key !== '') Configuration::updateValue('NTSUPPORT_API_KEY', $key);

            $out .= $this->displayConfirmation($this->l('Destek bağlantı ayarları kaydedildi.'));
        }

        $this->context->smarty->assign([
            'ntsupport_api_url' => Configuration::get('NTSUPPORT_API_URL'),
            'ntsupport_company' => Configuration::get('NTSUPPORT_COMPANY'),
            'ntsupport_key_saved' => (bool)Configuration::get('NTSUPPORT_API_KEY'),
            'ntsupport_panel_url' => $this->context->link->getAdminLink(self::TAB_CLASS),
        ]);
        return $out.$this->display(__FILE__, 'views/templates/admin/configure.tpl');
    }

    public function hookDisplayBackOfficeTop($params)
    {
        // Fail-safe: başka modülü veya BO'yu bozmaması için tüm işlem try/catch içinde.
        try {
            if (!$this->context->employee || !$this->context->employee->id) {
                return '';
            }

            $idTab = (int)Tab::getIdFromClassName(self::TAB_CLASS);
            if (!$idTab) return '';

            // PrestaShop 8 legacy permission API expects the action and the
            // controller class name. This is the same working pattern used by
            // our stable ntadvisorcommunication 1.3.0 header notification.
            if (!$this->context->employee->can('view', self::TAB_CLASS)) {
                return '';
            }

            // Merkezi sistemi her sayfa açılışında çağırma.
            // En fazla 10 dakikada bir, kısa timeout ile arka planda senkron kontrol.
            $last = (int)Configuration::get('NTSUPPORT_LAST_BADGE_SYNC');
            if ((time() - $last) >= 60) {
                Configuration::updateValue('NTSUPPORT_LAST_BADGE_SYNC', time());
                $this->syncTickets(true);
            }

            $count = (int)Db::getInstance()->getValue(
                'SELECT COUNT(*) FROM `'._DB_PREFIX_.'ntsupport_client_ticket`
                 WHERE last_support_message_id > last_seen_support_message_id'
            );

            $url = $this->context->link->getAdminLink(self::TAB_CLASS);
            $badge = $count > 0
                ? '<span style="background:#dc3545;color:#fff;border-radius:12px;padding:1px 7px;margin-left:6px;font-weight:700">'.$count.'</span>'
                : '';

            $notification = '';
            if ($count > 0) {
                $notification = '<a href="'.htmlspecialchars($url, ENT_QUOTES, 'UTF-8').'" class="ntsupport-toast" aria-label="'.$count.' yeni destek cevabı">
                    <span class="ntsupport-toast-icon" aria-hidden="true">&#128172;</span>
                    <span><strong>NetwoTürk Destek</strong><small>'.$count.' yeni destek cevabı var</small></span>
                    <b>'.$count.'</b>
                </a><style>
                    .ntsupport-toast{position:fixed;right:24px;bottom:24px;z-index:99999;display:flex;align-items:center;gap:11px;min-width:285px;padding:14px 16px;background:#003b53;color:#fff!important;border-radius:12px;text-decoration:none!important;box-shadow:0 10px 30px rgba(0,0,0,.28);animation:ntsupport-in .25s ease-out}
                    .ntsupport-toast-icon{display:flex;align-items:center;justify-content:center;width:38px;height:38px;border-radius:50%;background:#0b6074;font-size:20px}.ntsupport-toast span:nth-child(2){display:flex;flex:1;flex-direction:column}.ntsupport-toast strong{font-size:13px}.ntsupport-toast small{color:#d7edf1;margin-top:2px}.ntsupport-toast b{display:flex;align-items:center;justify-content:center;min-width:25px;height:25px;padding:0 7px;border-radius:14px;background:#dc3545;color:#fff}@keyframes ntsupport-in{from{opacity:0;transform:translateY(15px)}to{opacity:1;transform:none}}
                </style>';
            }

            return '<a href="'.htmlspecialchars($url, ENT_QUOTES, 'UTF-8').'"
                title="NetwoTürk Destek"
                style="display:inline-flex;align-items:center;height:36px;padding:0 13px;margin:7px 5px;border-radius:8px;background:#003B53;color:#fff;text-decoration:none;font-weight:600;box-shadow:0 2px 7px rgba(0,59,83,.18)">
                <span aria-hidden="true" style="font-size:18px;margin-right:7px">&#128172;</span> Destek Talepleri'.$badge.'
            </a>'.$notification;
        } catch (Throwable $e) {
            return '';
        }
    }

    public function syncTickets($silent = false)
    {
        $url = trim((string)Configuration::get('NTSUPPORT_API_URL'));
        $key = trim((string)Configuration::get('NTSUPPORT_API_KEY'));
        if ($url === '' || $key === '') {
            return [];
        }

        $rows = Db::getInstance()->executeS(
            'SELECT * FROM `'._DB_PREFIX_.'ntsupport_client_ticket`
             ORDER BY date_upd DESC LIMIT 50'
        );

        foreach ($rows as &$row) {
            $response = $this->apiPost([
                'action' => 'detail',
                'ticket_no' => $row['ticket_no'],
            ], $silent ? 2 : 8);

            if (!empty($response['ok']) && !empty($response['ticket'])) {
                $last = 0;
                $lastSupport = 0;
                foreach (($response['messages'] ?? []) as $message) {
                    $idMessage = (int)$message['id_message'];
                    $last = max($last, $idMessage);
                    if (($message['sender_type'] ?? '') === 'support') {
                        $lastSupport = max($lastSupport, $idMessage);
                    }
                }

                Db::getInstance()->update('ntsupport_client_ticket', [
                    'status' => pSQL((string)$response['ticket']['status']),
                    'last_message_id' => $last,
                    'last_support_message_id' => $lastSupport,
                    'date_upd' => pSQL((string)$response['ticket']['updated_at']),
                ], 'ticket_no="'.pSQL((string)$row['ticket_no']).'"');

                $row['status'] = (string)$response['ticket']['status'];
                $row['last_message_id'] = $last;
                $row['last_support_message_id'] = $lastSupport;
                $row['messages'] = $response['messages'] ?? [];
            }
        }
        unset($row);

        return $rows;
    }

    public function createTicket(array $data, ?array $file = null)
    {
        $payload = [
            'action' => 'create',
            'company' => (string)Configuration::get('NTSUPPORT_COMPANY'),
            'domain' => $this->currentDomain(),
            'product_name' => trim((string)($data['product_name'] ?? 'NetwoTürk Yazılım / Hizmet')),
            'license_id' => '',
            'contact_name' => trim((string)$data['contact_name']),
            'contact_phone' => trim((string)$data['contact_phone']),
            'contact_email' => trim((string)$data['contact_email']),
            'category' => trim((string)$data['category']),
            'priority' => trim((string)$data['priority']),
            'subject' => trim((string)$data['subject']),
            'message' => trim((string)$data['message']),
            'source' => 'ntsupport',
        ];

        if ($file && isset($file['error']) && (int)$file['error'] === UPLOAD_ERR_OK) {
            if ((int)$file['size'] > 5 * 1024 * 1024) {
                return ['ok' => false, 'error' => 'attachment_too_large'];
            }
            $mime = function_exists('mime_content_type')
                ? (string)mime_content_type($file['tmp_name'])
                : (string)$file['type'];

            if (!in_array($mime, ['image/jpeg', 'image/png', 'image/webp'], true)) {
                return ['ok' => false, 'error' => 'attachment_type'];
            }
            $raw = @file_get_contents($file['tmp_name']);
            if ($raw === false) return ['ok' => false, 'error' => 'attachment_read'];

            $payload['attachment_base64'] = base64_encode($raw);
            $payload['attachment_name'] = basename((string)$file['name']);
            $payload['attachment_mime'] = $mime;
        }

        $response = $this->apiPost($payload, 20);
        if (!empty($response['ok']) && !empty($response['ticket_no'])) {
            Db::getInstance()->insert('ntsupport_client_ticket', [
                'ticket_no' => pSQL((string)$response['ticket_no']),
                'subject' => pSQL((string)$payload['subject']),
                'status' => 'open',
                'last_message_id' => 1,
                'last_seen_message_id' => 1,
                'last_support_message_id' => 0,
                'last_seen_support_message_id' => 0,
                'created_by_employee' => (int)$this->context->employee->id,
                'date_add' => date('Y-m-d H:i:s'),
                'date_upd' => date('Y-m-d H:i:s'),
            ], false, true, Db::REPLACE);
        }
        return $response;
    }

    public function replyTicket($ticketNo, $message)
    {
        $employee = $this->context->employee;
        $response = $this->apiPost([
            'action' => 'reply',
            'ticket_no' => $ticketNo,
            'message' => $message,
            'contact_name' => trim((string)$employee->firstname.' '.(string)$employee->lastname),
        ], 15);

        if (!empty($response['ok'])) {
            Db::getInstance()->update('ntsupport_client_ticket', [
                'status' => 'open',
                'date_upd' => date('Y-m-d H:i:s'),
            ], 'ticket_no="'.pSQL($ticketNo).'"');
        }
        return $response;
    }

    public function markSeen($ticketNo, $lastMessageId)
    {
        return Db::getInstance()->update('ntsupport_client_ticket', [
            'last_seen_message_id' => (int)$lastMessageId,
        ], 'ticket_no="'.pSQL($ticketNo).'"');
    }

    public function markSupportSeen($ticketNo, $lastSupportMessageId)
    {
        return Db::getInstance()->update('ntsupport_client_ticket', [
            'last_seen_support_message_id' => (int)$lastSupportMessageId,
        ], 'ticket_no="'.pSQL($ticketNo).'"');
    }

    public function apiPost(array $payload, $timeout = 10)
    {
        $url = trim((string)Configuration::get('NTSUPPORT_API_URL'));
        $key = trim((string)Configuration::get('NTSUPPORT_API_KEY'));
        if ($url === '' || $key === '') {
            return ['ok' => false, 'error' => 'bridge_not_configured'];
        }
        if (!function_exists('curl_init')) {
            return ['ok' => false, 'error' => 'curl_missing'];
        }

        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CONNECTTIMEOUT => min(2, (int)$timeout),
            CURLOPT_TIMEOUT => (int)$timeout,
            CURLOPT_HTTPHEADER => [
                'X-NT-API-Key: '.$key,
                'Content-Type: application/x-www-form-urlencoded',
            ],
            CURLOPT_POSTFIELDS => http_build_query($payload, '', '&'),
        ]);

        $body = curl_exec($ch);
        $err = curl_error($ch);
        $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($body === false || $err !== '') {
            return ['ok' => false, 'error' => $err ?: 'connection_failed'];
        }

        $json = json_decode($body, true);
        if ($code < 200 || $code >= 300 || !is_array($json)) {
            return ['ok' => false, 'error' => 'HTTP '.$code];
        }
        return $json;
    }

    public function currentDomain()
    {
        $domain = (string)Tools::getHttpHost(false, false);
        $domain = preg_replace('#:\d+$#', '', $domain);
        return preg_replace('#^www\.#i', '', strtolower($domain));
    }

    public function isReady()
    {
        return (string)Configuration::get('NTSUPPORT_API_URL') !== ''
            && (string)Configuration::get('NTSUPPORT_API_KEY') !== ''
            && (string)Configuration::get('NTSUPPORT_COMPANY') !== '';
    }
}
