<?php
if (!defined('_PS_VERSION_')) { exit; }
function upgrade_module_1_1_1($module)
{
    $id = (int) Tab::getIdFromClassName('AdminNtSupportClient');
    if (!$id) { $id = (int) Tab::getIdFromClassName('AdminNtSupport'); }
    if (!$id) { return true; }
    $tab = new Tab($id);
    if (property_exists($tab, 'icon')) { $tab->icon = 'contact_support'; }
    return $tab->update();
}
