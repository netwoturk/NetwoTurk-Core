<?php

if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_1_1_0($module)
{
    if (!$module instanceof NtSupport) {
        return false;
    }

    if (!Configuration::get('NTSUPPORT_API_URL')) {
        Configuration::updateValue('NTSUPPORT_API_URL', 'https://netwoturktech.com/module/ntsupportcenter/api');
    }

    $dbReady = Db::getInstance()->execute(
        'CREATE TABLE IF NOT EXISTS `'._DB_PREFIX_.'ntsupport_client_ticket` (
            `id_local` INT UNSIGNED NOT NULL AUTO_INCREMENT,
            `ticket_no` VARCHAR(40) NOT NULL,
            `subject` VARCHAR(255) NOT NULL,
            `status` VARCHAR(30) NOT NULL DEFAULT "open",
            `last_message_id` INT UNSIGNED NOT NULL DEFAULT 0,
            `last_seen_message_id` INT UNSIGNED NOT NULL DEFAULT 0,
            `last_support_message_id` INT UNSIGNED NOT NULL DEFAULT 0,
            `last_seen_support_message_id` INT UNSIGNED NOT NULL DEFAULT 0,
            `created_by_employee` INT UNSIGNED NOT NULL DEFAULT 0,
            `date_add` DATETIME NOT NULL,
            `date_upd` DATETIME NOT NULL,
            PRIMARY KEY (`id_local`),
            UNIQUE KEY `ticket_no` (`ticket_no`)
        ) ENGINE='._MYSQL_ENGINE_.' DEFAULT CHARSET=utf8mb4'
    );
    if (!$dbReady || !$module->registerHook('displayBackOfficeTop')) {
        return false;
    }

    $oldId = (int)Tab::getIdFromClassName('AdminNtSupportClient');
    if ($oldId) {
        (new Tab($oldId))->delete();
    }

    $parentId = (int)Tab::getIdFromClassName('AdminNtModulesRoot');
    if (!$parentId) {
        $root = new Tab();
        $root->active = 1;
        $root->class_name = 'AdminNtModulesRoot';
        $root->module = $module->name;
        $root->id_parent = 0;
        if (property_exists($root, 'icon')) {
            $root->icon = 'extension';
        }
        foreach (Language::getLanguages(false) as $lang) {
            $root->name[(int)$lang['id_lang']] = 'NetwoTürk Modülleri';
        }
        if (!$root->add()) {
            return false;
        }
        $parentId = (int)$root->id;
    }

    $tabId = (int)Tab::getIdFromClassName(NtSupport::TAB_CLASS);
    $tab = $tabId ? new Tab($tabId) : new Tab();
    $tab->active = 1;
    $tab->class_name = NtSupport::TAB_CLASS;
    $tab->module = $module->name;
    $tab->id_parent = $parentId;
    if (property_exists($tab, 'icon')) {
        $tab->icon = 'support_agent';
    }
    foreach (Language::getLanguages(false) as $lang) {
        $tab->name[(int)$lang['id_lang']] = 'Destek Talepleri';
    }

    return $tabId ? $tab->update() : $tab->add();
}
