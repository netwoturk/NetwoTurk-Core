<?php

if (!defined('_PS_VERSION_')) {
    exit;
}

require_once __DIR__.'/AdminNtSupportController.php';

class AdminNtSupportClientController extends AdminNtSupportController
{
}
